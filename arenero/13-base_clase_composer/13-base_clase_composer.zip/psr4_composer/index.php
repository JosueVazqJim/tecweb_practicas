<?php
    use Webtechnologies\Config\Dev as Dev;
    require_once __DIR__ . '/app/start.php';
    $user = new Dev();
?> 