<?php
    use Webtechnologies\Models\User as User;
    require_once __DIR__ . '/app/start.php';
    $user = new User();
?> 