<?php
namespace Webtechnologies\Controllers;

class AccountController {
    public function __construct() {
        die('Account controller');
    }
}
?>