<?php
namespace Webtechnologies\Models;

class User {
    public function __construct() {
        die('User model');
    }
}
?>