<?php
    require_once __DIR__ . '/models/User.php';
    require_once __DIR__ . '/views/UserTemplate.php';
    require_once __DIR__ . '/controllers/UserController.php';
    require_once __DIR__ . '/models/Account.php';
    require_once __DIR__ . '/views/AccountTemplate.php';
    require_once __DIR__ . '/controllers/AccountController.php';

?>